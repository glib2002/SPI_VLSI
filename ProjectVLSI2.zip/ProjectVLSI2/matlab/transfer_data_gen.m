%randomizer for transfer data

%setting of script
bitness = 8;
max = power(2,bitness) - 1;
represantation = 0;       % 0 - dec, 1- bin, 2- hex

%generation part

mu = 1;
sigma = 5;
data_size = 1000;


pd = makedist('Normal');
data_buffer = round(abs(random(pd,[data_size,1,1]))*max);
for(n = 1:data_size)
  if(data_buffer(n)>max)
    data_buffer(n) = max;
   end
end

%disp(data_buffer);

ft=fopen('test_dat.txt','w');
fprintf(ft,'%d\n',data_buffer);
fclose(ft);


disp("Generation finished");

%type('test_dat.txt');
